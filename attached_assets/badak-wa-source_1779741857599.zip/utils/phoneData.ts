type ProviderInfo = { provider: string; region: string };

const PREFIX_MAP: Record<string, ProviderInfo> = {
  "62811": { provider: "Telkomsel", region: "DKI Jakarta" },
  "62812": { provider: "Telkomsel", region: "Jawa Barat" },
  "62813": { provider: "Telkomsel", region: "Jawa Tengah" },
  "62814": { provider: "Indosat Ooredoo", region: "DKI Jakarta" },
  "62815": { provider: "Indosat Ooredoo", region: "Jawa Barat" },
  "62816": { provider: "Indosat Ooredoo", region: "Jawa Timur" },
  "62817": { provider: "XL Axiata", region: "DKI Jakarta" },
  "62818": { provider: "XL Axiata", region: "Banten" },
  "62819": { provider: "XL Axiata", region: "Bali" },
  "62821": { provider: "Telkomsel", region: "Sumatera Utara" },
  "62822": { provider: "Telkomsel", region: "Sumatera Selatan" },
  "62823": { provider: "Telkomsel", region: "Sumatera Barat" },
  "62851": { provider: "Telkomsel", region: "Kalimantan" },
  "62852": { provider: "Telkomsel", region: "Sulawesi" },
  "62853": { provider: "Indosat Ooredoo", region: "Jawa Tengah" },
  "62854": { provider: "Indosat Ooredoo", region: "Bali" },
  "62855": { provider: "Indosat Ooredoo", region: "Sumatera" },
  "62856": { provider: "Indosat Ooredoo", region: "DKI Jakarta" },
  "62857": { provider: "Indosat Ooredoo", region: "Jawa Barat" },
  "62858": { provider: "Telkomsel", region: "Papua" },
  "62859": { provider: "Three (Tri)", region: "DKI Jakarta" },
  "62877": { provider: "XL Axiata", region: "Jawa Timur" },
  "62878": { provider: "XL Axiata", region: "Jawa Tengah" },
  "62879": { provider: "XL Axiata", region: "Sumatera" },
  "62881": { provider: "XL Axiata", region: "DKI Jakarta" },
  "62882": { provider: "XL Axiata", region: "Jawa Barat" },
  "62883": { provider: "XL Axiata", region: "Jawa Tengah" },
  "62895": { provider: "Three (Tri)", region: "Jawa Barat" },
  "62896": { provider: "Three (Tri)", region: "Jawa Tengah" },
  "62897": { provider: "Three (Tri)", region: "Jawa Timur" },
  "62898": { provider: "Three (Tri)", region: "Sumatera" },
  "62899": { provider: "Three (Tri)", region: "Bali" },
  "62838": { provider: "Axis", region: "DKI Jakarta" },
  "62831": { provider: "Telkomsel", region: "Kalimantan Timur" },
  "62832": { provider: "Telkomsel", region: "Nusa Tenggara" },
  "62833": { provider: "Telkomsel", region: "Maluku" },
};

const COUNTRY_PREFIX_MAP: Record<string, { country: string; operator: string }> = {
  "1": { country: "Amerika Serikat", operator: "US Carrier" },
  "44": { country: "Inggris", operator: "UK Carrier" },
  "91": { country: "India", operator: "IN Carrier" },
  "60": { country: "Malaysia", operator: "MY Carrier" },
  "65": { country: "Singapura", operator: "SG Carrier" },
  "66": { country: "Thailand", operator: "TH Carrier" },
  "84": { country: "Vietnam", operator: "VN Carrier" },
  "63": { country: "Filipina", operator: "PH Carrier" },
  "49": { country: "Jerman", operator: "DE Carrier" },
  "33": { country: "Prancis", operator: "FR Carrier" },
  "39": { country: "Italia", operator: "IT Carrier" },
  "7": { country: "Rusia", operator: "RU Carrier" },
  "86": { country: "China", operator: "CN Carrier" },
  "81": { country: "Jepang", operator: "JP Carrier" },
  "82": { country: "Korea Selatan", operator: "KR Carrier" },
  "61": { country: "Australia", operator: "AU Carrier" },
  "55": { country: "Brasil", operator: "BR Carrier" },
  "52": { country: "Meksiko", operator: "MX Carrier" },
  "27": { country: "Afrika Selatan", operator: "ZA Carrier" },
  "20": { country: "Mesir", operator: "EG Carrier" },
  "971": { country: "UAE", operator: "AE Carrier" },
  "966": { country: "Arab Saudi", operator: "SA Carrier" },
  "90": { country: "Turki", operator: "TR Carrier" },
  "62": { country: "Indonesia", operator: "ID Carrier" },
};

export function getProviderInfo(phone: string): ProviderInfo {
  const cleaned = phone.replace(/^\+/, "").replace(/[\s\-()]/g, "");
  if (cleaned.startsWith("62")) {
    const prefix5 = cleaned.substring(0, 5);
    if (PREFIX_MAP[prefix5]) return PREFIX_MAP[prefix5];
    const prefix4 = cleaned.substring(0, 4);
    const fallback = Object.entries(PREFIX_MAP).find(([k]) => k.startsWith(prefix4));
    if (fallback) return fallback[1];
  }
  for (const [code, info] of Object.entries(COUNTRY_PREFIX_MAP)) {
    if (cleaned.startsWith(code)) {
      return { provider: info.operator, region: info.country };
    }
  }
  return { provider: "Unknown Carrier", region: "International" };
}

export function getCardAge(phone: string): string {
  let seed = 0;
  for (let i = 0; i < phone.length; i++) seed += phone.charCodeAt(i);
  const months = (seed % 90) + 6;
  if (months < 12) return `${months} bulan`;
  const years = Math.floor(months / 12);
  const rem = months % 12;
  return rem > 0 ? `${years} tahun ${rem} bulan` : `${years} tahun`;
}

export function getNumberStatus(phone: string): string {
  let seed = 0;
  for (let i = 0; i < phone.length; i++) seed += phone.charCodeAt(i);
  const statuses = ["Aktif", "Aktif", "Aktif", "Tidak Aktif", "Aktif"];
  return statuses[seed % statuses.length];
}

export function validatePhone(value: string): string | null {
  if (!value || !value.trim()) return "Nomor tidak boleh kosong";
  const cleaned = value.replace(/[\s\-\(\)]/g, "").replace(/^\+/, "");
  if (!/^\d+$/.test(cleaned)) return "Nomor hanya boleh angka atau + di awal";
  if (cleaned.length < 6) return "Nomor terlalu pendek (min 6 digit)";
  if (cleaned.length > 15) return "Nomor terlalu panjang (max 15 digit)";
  return null;
}
