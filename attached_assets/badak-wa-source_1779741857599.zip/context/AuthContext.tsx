import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export type Account = {
  username: string;
  password: string;
  expiredAt: number | null;
  isVip: boolean;
};

export type Session = {
  username: string;
  expiredAt: number | null;
  isVip: boolean;
};

export type LoginResult =
  | "OK"
  | "USER_NOT_FOUND"
  | "WRONG_PASSWORD"
  | "EXPIRED";

type AuthContextType = {
  session: Session | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<LoginResult>;
  logout: () => Promise<void>;
};

const ACCOUNTS_KEY = "badak_accounts";
const SESSION_KEY = "badak_session";

const DEMO_ACCOUNTS: Account[] = [
  {
    username: "demo",
    password: "demo123",
    expiredAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
    isVip: false,
  },
  { username: "vip", password: "vip123", expiredAt: null, isVip: true },
  {
    username: "budi",
    password: "badak123",
    expiredAt: Date.now() + 30 * 24 * 60 * 60 * 1000,
    isVip: false,
  },
];

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void init();
  }, []);

  async function init() {
    const stored = await AsyncStorage.getItem(ACCOUNTS_KEY);
    if (!stored) {
      await AsyncStorage.setItem(ACCOUNTS_KEY, JSON.stringify(DEMO_ACCOUNTS));
    }
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) {
        const sess: Session = JSON.parse(raw) as Session;
        if (sess.expiredAt !== null && Date.now() > sess.expiredAt) {
          await AsyncStorage.removeItem(SESSION_KEY);
        } else {
          setSession(sess);
        }
      }
    } catch (_) {}
    setLoading(false);
  }

  const login = useCallback(
    async (username: string, password: string): Promise<LoginResult> => {
      const raw = await AsyncStorage.getItem(ACCOUNTS_KEY);
      const accounts: Account[] = raw
        ? (JSON.parse(raw) as Account[])
        : DEMO_ACCOUNTS;
      const account = accounts.find(
        (a) => a.username.toLowerCase() === username.toLowerCase()
      );
      if (!account) return "USER_NOT_FOUND";
      if (account.password !== password) return "WRONG_PASSWORD";
      if (account.expiredAt !== null && Date.now() > account.expiredAt)
        return "EXPIRED";
      const sess: Session = {
        username: account.username,
        expiredAt: account.expiredAt,
        isVip: account.isVip,
      };
      await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(sess));
      setSession(sess);
      return "OK";
    },
    []
  );

  const logout = useCallback(async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    setSession(null);
  }, []);

  return (
    <AuthContext.Provider value={{ session, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
