const palette = {
  text: "#ffffff",
  tint: "#e63946",
  background: "#0a0f2c",
  foreground: "#ffffff",
  card: "#1a2040",
  cardForeground: "#ffffff",
  primary: "#e63946",
  primaryForeground: "#ffffff",
  secondary: "#1a2040",
  secondaryForeground: "#8892b0",
  muted: "#0d1535",
  mutedForeground: "#8892b0",
  accent: "#e63946",
  accentForeground: "#ffffff",
  destructive: "#e63946",
  destructiveForeground: "#ffffff",
  border: "#2a3060",
  input: "#0d1535",
  success: "#2ecc71",
  gold: "#f4c430",
};

const colors = {
  light: palette,
  dark: palette,
  radius: 8,
};

export default colors;
