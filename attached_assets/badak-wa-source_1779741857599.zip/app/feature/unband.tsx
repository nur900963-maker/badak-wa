import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import ResultView from "@/components/ResultView";
import { validatePhone } from "@/utils/phoneData";

const STEPS_NORMAL = [
  "Mendeteksi status ban akun...",
  "Menghubungi server WhatsApp...",
  "Mengirim permintaan unban...",
  "Memverifikasi identitas...",
  "Unban berhasil diproses!",
];
const STEPS_FORCE = [
  "Mengaktifkan mode force bypass...",
  "Mendeteksi celah sistem...",
  "Memaksa unban via server internal...",
  "Memvalidasi sesi baru...",
  "Force unban berhasil!",
];

export default function UnbandScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [method, setMethod] = useState<"Normal" | "Force">("Normal");
  const [error, setError] = useState("");

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  return (
    <FeatureContainer title="UNBAND" onBack={() => router.back()} scrollable={phase === "input"}>
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>METODE</Text>
          <View style={styles.methodRow}>
            {(["Normal", "Force"] as const).map((m) => (
              <TouchableOpacity key={m} onPress={() => setMethod(m)} activeOpacity={0.8} style={{ flex: 1 }}>
                {method === m ? (
                  <LinearGradient colors={["#2ecc71", "#1a8a4e"]} style={styles.methodBtnActive}>
                    <Text style={styles.methodBtnTextActive}>{m === "Force" ? "⚡ Force" : "🛡 Normal"}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.methodBtn}>
                    <Text style={styles.methodBtnText}>{m === "Force" ? "⚡ Force" : "🛡 Normal"}</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>NOMOR TARGET</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <Text style={styles.inputPrefix}>+</Text>
            <TextInput
              style={styles.input}
              placeholder="Semua negara (628xx / +1xxx / dll)"
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t.replace(/[^\d+\s\-()]/g, "")); setError(""); }}
              keyboardType="phone-pad"
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}

          <TouchableOpacity onPress={run} disabled={!target.trim()} activeOpacity={0.85}>
            <LinearGradient
              colors={target.trim() ? ["#2ecc71", "#1a8a4e"] : ["#2a3060", "#2a3060"]}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>🛡 UNBAND!</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
      {phase === "progress" && (
        <ProgressView steps={method === "Normal" ? STEPS_NORMAL : STEPS_FORCE} stepDuration={1100} onComplete={() => setPhase("result")} />
      )}
      {phase === "result" && (
        <ResultView
          title="UNBAN BERHASIL ✅"
          iconName="check-circle"
          iconColor="#2ecc71"
          details={`Target: +${target}\nMetode: ${method}`}
          onReset={() => { setPhase("input"); setTarget(""); }}
          onBack={() => router.back()}
        />
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 14 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  methodRow: { flexDirection: "row", gap: 10 },
  methodBtn: { paddingVertical: 14, borderRadius: 12, backgroundColor: "#111827", borderWidth: 1, borderColor: "#2a3060", alignItems: "center" },
  methodBtnActive: { paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  methodBtnText: { color: "#8892b0", fontSize: 15, fontFamily: "Rajdhani_700Bold" },
  methodBtnTextActive: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold" },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: "#0d1535", borderRadius: 12, borderWidth: 1, borderColor: "#2a3060", paddingHorizontal: 14, height: 54 },
  inputWrapError: { borderColor: "#e63946" },
  inputPrefix: { color: "#4da6ff", fontSize: 18, fontFamily: "Rajdhani_700Bold", marginRight: 6 },
  input: { flex: 1, color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 4 },
  runBtnText: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
});
