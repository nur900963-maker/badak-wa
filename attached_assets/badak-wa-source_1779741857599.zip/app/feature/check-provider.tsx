import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import { getNumberStatus, getProviderInfo, validatePhone } from "@/utils/phoneData";

const STEPS = [
  "Menganalisis prefix nomor...",
  "Mencocokkan database provider global...",
  "Mendapatkan informasi regional...",
  "Memverifikasi status aktif...",
  "Analisis selesai!",
];

export default function CheckProviderScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ provider: string; region: string; status: string } | null>(null);

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  const handleComplete = () => {
    const info = getProviderInfo(target);
    const status = getNumberStatus(target);
    setResult({ ...info, status });
    setPhase("result");
  };

  const statusColor = result?.status === "Aktif" ? "#2ecc71" : "#e63946";

  return (
    <FeatureContainer title="CEK PROVIDER" onBack={() => router.back()} scrollable={phase === "input"}>
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>NOMOR TARGET (SEMUA NEGARA)</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <Text style={styles.inputPrefix}>+</Text>
            <TextInput
              style={styles.input}
              placeholder="Nomor semua negara (628xx / +1xxx / dll)"
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t.replace(/[^\d+\s\-()]/g, "")); setError(""); }}
              keyboardType="phone-pad"
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}
          <TouchableOpacity onPress={run} disabled={!target.trim()} activeOpacity={0.85}>
            <LinearGradient
              colors={target.trim() ? ["#1a6ef7", "#0d4bcc"] : ["#2a3060", "#2a3060"]}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>📡 CEK PROVIDER</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={900} onComplete={handleComplete} />
      )}

      {phase === "result" && result && (
        <View style={styles.resultContainer}>
          <LinearGradient colors={["#1a2040", "#0a0f2c"]} style={styles.resultCard}>
            <View style={styles.resultIconWrap}>
              <Feather name="wifi" size={40} color="#1a6ef7" />
            </View>
            <Text style={styles.resultTitle}>HASIL CEK PROVIDER</Text>
            {[
              { key: "Nomor", val: `+${target}`, color: "#ffffff" },
              { key: "Provider", val: result.provider, color: "#1a6ef7" },
              { key: "Negara / Wilayah", val: result.region, color: "#ffffff" },
              { key: "Status", val: result.status, color: statusColor },
            ].map(({ key, val, color }) => (
              <View key={key} style={styles.resultRow}>
                <Text style={styles.resultKey}>{key}</Text>
                <Text style={[styles.resultVal, { color }]}>{val}</Text>
              </View>
            ))}
            <Text style={styles.powered}>⚡ Powered by @pakvncnt</Text>
          </LinearGradient>
          <TouchableOpacity style={styles.resetBtn} onPress={() => { setPhase("input"); setTarget(""); setResult(null); }}>
            <Text style={styles.resetBtnText}>↩ CEK NOMOR LAIN</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.back()}>
            <LinearGradient colors={["#e63946", "#c0392b"]} style={styles.backBtn}>
              <Text style={styles.backBtnText}>← KEMBALI KE MENU</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 14 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: "#0d1535", borderRadius: 12, borderWidth: 1, borderColor: "#2a3060", paddingHorizontal: 14, height: 54 },
  inputWrapError: { borderColor: "#e63946" },
  inputPrefix: { color: "#4da6ff", fontSize: 18, fontFamily: "Rajdhani_700Bold", marginRight: 6 },
  input: { flex: 1, color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 4 },
  runBtnText: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  resultContainer: { gap: 12 },
  resultCard: { borderRadius: 20, padding: 24, alignItems: "center", gap: 14, borderWidth: 1, borderColor: "#2a3060" },
  resultIconWrap: { width: 72, height: 72, borderRadius: 20, backgroundColor: "#1a6ef720", borderWidth: 1, borderColor: "#1a6ef755", alignItems: "center", justifyContent: "center" },
  resultTitle: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  resultRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", width: "100%", paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: "#1a2040" },
  resultKey: { color: "#8892b0", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  resultVal: { fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  powered: { color: "#2a3060", fontSize: 12, fontFamily: "Rajdhani_400Regular", marginTop: 4 },
  resetBtn: { borderRadius: 14, padding: 15, alignItems: "center", borderWidth: 1, borderColor: "#2a3060", backgroundColor: "#111827" },
  resetBtnText: { color: "#8892b0", fontSize: 15, fontFamily: "Rajdhani_700Bold" },
  backBtn: { borderRadius: 14, height: 54, alignItems: "center", justifyContent: "center" },
  backBtnText: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
});
