import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import ResultView from "@/components/ResultView";

const STEPS_VPS = [
  "Menganalisis target VPS...",
  "Memindai port yang terbuka...",
  "Mengirim payload shutdown...",
  "Memutus koneksi server...",
  "VPS berhasil dinonaktifkan!",
];
const STEPS_PANEL = [
  "Mendeteksi jenis panel...",
  "Bypass autentikasi panel...",
  "Menginjeksi shutdown command...",
  "Menghapus sesi aktif...",
  "Panel berhasil dinonaktifkan!",
];

export default function KillScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [type, setType] = useState<"VPS" | "Panel">("VPS");
  const [error, setError] = useState("");

  const run = () => {
    if (!target.trim()) { setError("IP / URL tidak boleh kosong"); return; }
    setError("");
    setPhase("progress");
  };

  return (
    <FeatureContainer title={`KILL ${type}`} onBack={() => router.back()} scrollable={phase === "input"}>
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>TARGET TYPE</Text>
          <View style={styles.typeRow}>
            {(["VPS", "Panel"] as const).map((t) => (
              <TouchableOpacity key={t} onPress={() => setType(t)} activeOpacity={0.8} style={{ flex: 1 }}>
                {type === t ? (
                  <LinearGradient colors={["#ff4136", "#8b0000"]} style={styles.typeBtnActive}>
                    <Text style={styles.typeBtnTextActive}>{t === "VPS" ? "🖥 Kill VPS" : "⚙ Kill Panel"}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.typeBtn}>
                    <Text style={styles.typeBtnText}>{t === "VPS" ? "🖥 Kill VPS" : "⚙ Kill Panel"}</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>{type === "VPS" ? "IP ADDRESS / DOMAIN" : "URL PANEL"}</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <TextInput
              style={styles.input}
              placeholder={type === "VPS" ? "192.168.x.x atau domain.com" : "https://panel.domain.com"}
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t); setError(""); }}
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}

          <View style={styles.dangerBox}>
            <Text style={styles.dangerText}>⚠ Aksi ini tidak dapat dibatalkan setelah dieksekusi</Text>
          </View>

          <TouchableOpacity onPress={run} disabled={!target.trim()} activeOpacity={0.85}>
            <LinearGradient
              colors={target.trim() ? ["#ff4136", "#8b0000"] : ["#2a3060", "#2a3060"]}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>💀 KILL!</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
      {phase === "progress" && (
        <ProgressView steps={type === "VPS" ? STEPS_VPS : STEPS_PANEL} stepDuration={1200} onComplete={() => setPhase("result")} />
      )}
      {phase === "result" && (
        <ResultView
          title={type === "VPS" ? "VPS NONAKTIF 💀" : "PANEL NONAKTIF 💀"}
          iconName="x-circle"
          iconColor="#ff4136"
          details={`Target: ${target}\nStatus: Nonaktif`}
          onReset={() => { setPhase("input"); setTarget(""); }}
          onBack={() => router.back()}
        />
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 14 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  typeRow: { flexDirection: "row", gap: 10 },
  typeBtn: { paddingVertical: 14, borderRadius: 12, backgroundColor: "#111827", borderWidth: 1, borderColor: "#2a3060", alignItems: "center" },
  typeBtnActive: { paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  typeBtnText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  typeBtnTextActive: { color: "#ffffff", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  inputWrap: { backgroundColor: "#0d1535", borderRadius: 12, borderWidth: 1, borderColor: "#2a3060", paddingHorizontal: 14, height: 54, justifyContent: "center" },
  inputWrapError: { borderColor: "#e63946" },
  input: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_400Regular" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  dangerBox: { backgroundColor: "#1a0000", borderRadius: 10, padding: 12, borderWidth: 1, borderColor: "#ff413655" },
  dangerText: { color: "#ff4136", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 4 },
  runBtnText: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
});
