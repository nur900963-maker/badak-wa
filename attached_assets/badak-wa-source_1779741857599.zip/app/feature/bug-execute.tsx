import { LinearGradient } from "expo-linear-gradient";
import { router, useLocalSearchParams } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import ResultView from "@/components/ResultView";
import { validatePhone } from "@/utils/phoneData";

const STEPS = [
  "Menyiapkan payload bug...",
  "Menghubungkan ke server target...",
  "Mengeksekusi bug...",
  "Menunggu respons server...",
  "Eksekusi berhasil!",
];

export default function BugExecuteScreen() {
  const { bugName } = useLocalSearchParams<{ bugName: string }>();
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [error, setError] = useState("");

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  return (
    <FeatureContainer
      title={bugName ?? "BUG"}
      onBack={() => router.back()}
      scrollable={phase === "input"}
    >
      {phase === "input" && (
        <View style={styles.form}>
          <View style={styles.bugTag}>
            <Text style={styles.bugTagText}>BUG TYPE: {bugName}</Text>
          </View>

          <Text style={styles.label}>NOMOR / USERNAME TARGET</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <Text style={styles.inputPrefix}>+</Text>
            <TextInput
              style={styles.input}
              placeholder="Semua nomor negara (628xx / +1xxx / dll)"
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t.replace(/[^\d+\s\-()]/g, "")); setError(""); }}
              keyboardType="phone-pad"
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}

          <TouchableOpacity onPress={run} disabled={!target.trim()} activeOpacity={0.85}>
            <LinearGradient
              colors={target.trim() ? ["#ff8c00", "#e65c00"] : ["#2a3060", "#2a3060"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>💥 EKSEKUSI!</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={1000} onComplete={() => setPhase("result")} />
      )}

      {phase === "result" && (
        <ResultView
          title="BERHASIL ✅"
          iconName="check-circle"
          iconColor="#2ecc71"
          details={`Bug: ${bugName ?? "Unknown"}\nTarget: +${target}`}
          onReset={() => { setPhase("input"); setTarget(""); }}
          onBack={() => router.back()}
        />
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 12 },
  bugTag: {
    backgroundColor: "#1a1000",
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#ff8c0055",
    alignSelf: "flex-start",
  },
  bugTagText: { color: "#ff8c00", fontSize: 13, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0d1535",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#2a3060",
    paddingHorizontal: 14,
    height: 54,
  },
  inputWrapError: { borderColor: "#e63946" },
  inputPrefix: { color: "#4da6ff", fontSize: 18, fontFamily: "Rajdhani_700Bold", marginRight: 6 },
  input: { flex: 1, color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 8 },
  runBtnText: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
});
