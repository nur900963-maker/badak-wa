import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import ResultView from "@/components/ResultView";
import { validatePhone } from "@/utils/phoneData";

type CountOption = number | "ALL";

const COUNTS: CountOption[] = [1, 10, 50, 100, 500, 1000, 5000, "ALL"];

const STEPS = [
  "Menghubungkan ke server WhatsApp...",
  "Mencari database target...",
  "Menyiapkan payload badak...",
  "Mengirim badak ke target...",
  "Selesai! Semua terkirim.",
];

export default function BadakWAScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [count, setCount] = useState<CountOption>(10);
  const [error, setError] = useState("");

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  const countLabel = count === "ALL" ? "ALL (5000+)" : `${count}`;

  return (
    <FeatureContainer
      title="BADAK WA"
      onBack={() => router.back()}
      scrollable={phase === "input"}
    >
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>NOMOR TARGET</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <Text style={styles.inputPrefix}>+</Text>
            <TextInput
              style={styles.input}
              placeholder="Nomor semua negara (contoh: 628123456789)"
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t.replace(/[^\d+\s\-()]/g, "")); setError(""); }}
              keyboardType="phone-pad"
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}

          <Text style={[styles.label, { marginTop: 6 }]}>JUMLAH BLAST</Text>
          <View style={styles.countGrid}>
            {COUNTS.map((c) => {
              const active = count === c;
              return (
                <TouchableOpacity
                  key={String(c)}
                  onPress={() => setCount(c)}
                  activeOpacity={0.75}
                >
                  {active ? (
                    <LinearGradient
                      colors={["#e63946", "#c0392b"]}
                      style={styles.countBtnActive}
                    >
                      <Text style={styles.countBtnTextActive}>{c === "ALL" ? "ALL 🔥" : c}</Text>
                    </LinearGradient>
                  ) : (
                    <View style={styles.countBtn}>
                      <Text style={styles.countBtnText}>{c === "ALL" ? "ALL 🔥" : c}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>

          {count === "ALL" && (
            <View style={styles.warningBox}>
              <Text style={styles.warningText}>⚡ Mode ALL akan mengirim 5000+ blast ke target</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={run}
            disabled={!target.trim()}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={target.trim() ? ["#e63946", "#c0392b"] : ["#2a3060", "#2a3060"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>⚡ BADAK!</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={1100} onComplete={() => setPhase("result")} />
      )}

      {phase === "result" && (
        <ResultView
          title="BADAK TERKIRIM ✅"
          iconName="check-circle"
          iconColor="#2ecc71"
          details={`Target: +${target}\nJumlah: ${countLabel} blast berhasil dikirim`}
          onReset={() => { setPhase("input"); setTarget(""); }}
          onBack={() => router.back()}
        />
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 12 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0d1535",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#2a3060",
    paddingHorizontal: 14,
    height: 54,
  },
  inputWrapError: { borderColor: "#e63946" },
  inputPrefix: { color: "#4da6ff", fontSize: 18, fontFamily: "Rajdhani_700Bold", marginRight: 6 },
  input: {
    flex: 1,
    color: "#ffffff",
    fontSize: 16,
    fontFamily: "Rajdhani_400Regular",
  },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  countGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  countBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: "#111827",
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  countBtnActive: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 10,
  },
  countBtnText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  countBtnTextActive: { color: "#ffffff", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  warningBox: {
    backgroundColor: "#1a1000",
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: "#ff8c0055",
  },
  warningText: { color: "#ff8c00", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 8 },
  runBtnText: { color: "#ffffff", fontSize: 22, fontFamily: "Rajdhani_700Bold", letterSpacing: 3 },
});
