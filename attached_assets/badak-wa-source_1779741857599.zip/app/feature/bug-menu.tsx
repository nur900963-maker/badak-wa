import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "@/components/BrandingBar";

type Bug = { name: string; isVip?: boolean };

const BUGS: Bug[] = [
  { name: "Aroxen" },
  { name: "Travaz" },
  { name: "Lochturn" },
  { name: "Overhold" },
  { name: "Hitnative" },
  { name: "Zipx" },
  { name: "Sepongip" },
  { name: "Ziosx" },
  { name: "Delay Hardd", isVip: true },
  { name: "Crasher Track", isVip: true },
  { name: "Invisible Bug", isVip: true },
  { name: "Crash IP", isVip: true },
];

export default function BugMenuScreen() {
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const [vipModal, setVipModal] = useState(false);

  const handleBugTap = (bug: Bug) => {
    if (bug.isVip) {
      setVipModal(true);
      return;
    }
    router.push({
      pathname: "/feature/bug-execute",
      params: { bugName: bug.name },
    });
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <BrandingBar />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color="#ffffff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>BUG MENU</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={[styles.grid, { paddingBottom: bottomPad + 24 }]}>
        {BUGS.map((bug) => (
          <TouchableOpacity
            key={bug.name}
            style={[styles.bugCard, bug.isVip && styles.bugCardVip]}
            onPress={() => handleBugTap(bug)}
            activeOpacity={0.8}
          >
            {bug.isVip && (
              <View style={styles.vipOverlay}>
                <Feather name="lock" size={18} color="#f4c430" />
                <Text style={styles.vipText}>VIP</Text>
              </View>
            )}
            <Feather
              name="alert-triangle"
              size={24}
              color={bug.isVip ? "#f4c430" : "#e63946"}
            />
            <Text style={[styles.bugName, bug.isVip && styles.bugNameVip]}>
              {bug.name}
            </Text>
            {!bug.isVip && (
              <Feather name="chevron-right" size={16} color="#2a3060" />
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Modal visible={vipModal} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Feather name="lock" size={40} color="#f4c430" />
            <Text style={styles.modalTitle}>Bug VIP</Text>
            <Text style={styles.modalText}>
              Bug ini khusus pengguna VIP.{"\n"}Hubungi @pakvncnt untuk akses.
            </Text>
            <TouchableOpacity style={styles.modalBtn} onPress={() => setVipModal(false)}>
              <Text style={styles.modalBtnText}>TUTUP</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0a0f2c" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#2a3060",
  },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  grid: { padding: 16, gap: 10 },
  bugCard: {
    backgroundColor: "#1a2040",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  bugCardVip: { borderColor: "#f4c430", opacity: 0.7 },
  vipOverlay: { position: "absolute", right: 14, top: "50%", marginTop: -12, flexDirection: "row", gap: 4, alignItems: "center" },
  vipText: { color: "#f4c430", fontSize: 12, fontFamily: "Rajdhani_700Bold" },
  bugName: { color: "#ffffff", fontSize: 17, fontFamily: "Rajdhani_700Bold", flex: 1 },
  bugNameVip: { color: "#f4c430" },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", alignItems: "center", justifyContent: "center", padding: 24 },
  modal: {
    backgroundColor: "#1a2040",
    borderRadius: 16,
    padding: 24,
    width: "100%",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#f4c430",
    gap: 12,
  },
  modalTitle: { color: "#f4c430", fontSize: 22, fontFamily: "Rajdhani_700Bold" },
  modalText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_400Regular", textAlign: "center", lineHeight: 22 },
  modalBtn: { backgroundColor: "#e63946", borderRadius: 10, paddingHorizontal: 32, paddingVertical: 12 },
  modalBtnText: { color: "#ffffff", fontFamily: "Rajdhani_700Bold", fontSize: 15 },
});
