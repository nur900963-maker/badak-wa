import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import ResultView from "@/components/ResultView";

const COUNTS = [1, 5, 10, 50, 100, 500, 1000, 5000];
const STEPS = [
  "Menyiapkan akun reporter...",
  "Menghubungkan ke sistem Telegram...",
  "Mengirim laporan...",
  "Memproses respons server...",
  "Semua laporan terkirim!",
];

export default function ReportScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [count, setCount] = useState(10);
  const [type, setType] = useState<"Account" | "Channel">("Account");
  const [error, setError] = useState("");

  const run = () => {
    if (!target.trim()) { setError("Username tidak boleh kosong"); return; }
    setError("");
    setPhase("progress");
  };

  return (
    <FeatureContainer title="REPORT" onBack={() => router.back()} scrollable={phase === "input"}>
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>TIPE LAPORAN</Text>
          <View style={styles.typeRow}>
            {(["Account", "Channel"] as const).map((t) => (
              <TouchableOpacity key={t} onPress={() => setType(t)} activeOpacity={0.8} style={{ flex: 1 }}>
                {type === t ? (
                  <LinearGradient colors={["#b10dc9", "#6a0080"]} style={styles.typeBtnActive}>
                    <Text style={styles.typeBtnTextActive}>{t === "Account" ? "👤 Account" : "📢 Channel"}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.typeBtn}>
                    <Text style={styles.typeBtnText}>{t === "Account" ? "👤 Account" : "📢 Channel"}</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.label}>@USERNAME TARGET</Text>
          <View style={[styles.inputWrap, error ? styles.inputWrapError : null]}>
            <Text style={styles.inputPrefix}>@</Text>
            <TextInput
              style={styles.input}
              placeholder="username_target"
              placeholderTextColor="#4a5280"
              value={target}
              onChangeText={(t) => { setTarget(t.replace("@", "")); setError(""); }}
              autoCapitalize="none"
            />
          </View>
          {error ? <Text style={styles.errorText}>⚠ {error}</Text> : null}

          <Text style={styles.label}>JUMLAH REPORT</Text>
          <View style={styles.countGrid}>
            {COUNTS.map((c) => (
              <TouchableOpacity key={c} onPress={() => setCount(c)} activeOpacity={0.75}>
                {count === c ? (
                  <LinearGradient colors={["#b10dc9", "#6a0080"]} style={styles.countBtnActive}>
                    <Text style={styles.countBtnTextActive}>{c >= 1000 ? `${c/1000}K` : c}</Text>
                  </LinearGradient>
                ) : (
                  <View style={styles.countBtn}>
                    <Text style={styles.countBtnText}>{c >= 1000 ? `${c/1000}K` : c}</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>

          <TouchableOpacity onPress={run} disabled={!target.trim()} activeOpacity={0.85}>
            <LinearGradient
              colors={target.trim() ? ["#b10dc9", "#6a0080"] : ["#2a3060", "#2a3060"]}
              style={styles.runBtn}
            >
              <Text style={styles.runBtnText}>🚩 REPORT!</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={1000} onComplete={() => setPhase("result")} />
      )}
      {phase === "result" && (
        <ResultView
          title="REPORT TERKIRIM ✅"
          iconName="check-circle"
          iconColor="#b10dc9"
          details={`Target: @${target}\nTipe: ${type}\nTotal: ${count} report terkirim`}
          onReset={() => { setPhase("input"); setTarget(""); }}
          onBack={() => router.back()}
        />
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 14 },
  label: { color: "#4da6ff", fontSize: 12, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  typeRow: { flexDirection: "row", gap: 10 },
  typeBtn: { paddingVertical: 14, borderRadius: 12, backgroundColor: "#111827", borderWidth: 1, borderColor: "#2a3060", alignItems: "center" },
  typeBtnActive: { paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  typeBtnText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  typeBtnTextActive: { color: "#ffffff", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: "#0d1535", borderRadius: 12, borderWidth: 1, borderColor: "#2a3060", paddingHorizontal: 14, height: 54 },
  inputWrapError: { borderColor: "#e63946" },
  inputPrefix: { color: "#b10dc9", fontSize: 20, fontFamily: "Rajdhani_700Bold", marginRight: 6 },
  input: { flex: 1, color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  countGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  countBtn: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10, backgroundColor: "#111827", borderWidth: 1, borderColor: "#2a3060" },
  countBtnActive: { paddingHorizontal: 18, paddingVertical: 10, borderRadius: 10 },
  countBtnText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  countBtnTextActive: { color: "#ffffff", fontSize: 14, fontFamily: "Rajdhani_700Bold" },
  runBtn: { borderRadius: 14, height: 56, alignItems: "center", justifyContent: "center", marginTop: 4 },
  runBtnText: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
});
