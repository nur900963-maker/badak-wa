import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import { getCardAge, getProviderInfo, validatePhone } from "@/utils/phoneData";

const STEPS = [
  "Menganalisis registrasi nomor...",
  "Memeriksa riwayat aktivasi...",
  "Mengestimasi umur kartu...",
  "Memverifikasi data...",
  "Analisis selesai!",
];

export default function CekUmurScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ age: string; provider: string } | null>(null);

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  const handleComplete = () => {
    const age = getCardAge(target);
    const { provider } = getProviderInfo(target);
    setResult({ age, provider });
    setPhase("result");
  };

  return (
    <FeatureContainer
      title="CEK UMUR KARTU"
      onBack={() => router.back()}
      scrollable={phase === "input"}
    >
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>Nomor Kartu</Text>
          <TextInput
            style={[styles.input, error ? styles.inputError : null]}
            placeholder="62812xxxxxxx"
            placeholderTextColor="#4a5280"
            value={target}
            onChangeText={(t) => { setTarget(t.replace(/\D/g, "")); setError(""); }}
            keyboardType="numeric"
          />
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          <TouchableOpacity
            style={[styles.runBtn, !target && styles.runBtnDisabled]}
            onPress={run}
            disabled={!target}
            activeOpacity={0.85}
          >
            <Text style={styles.runBtnText}>CEK UMUR</Text>
          </TouchableOpacity>
        </View>
      )}

      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={900} onComplete={handleComplete} />
      )}

      {phase === "result" && result && (
        <View style={styles.resultContainer}>
          <View style={styles.resultCard}>
            <Feather name="clock" size={48} color="#2ecc71" />
            <Text style={styles.resultTitle}>HASIL CEK UMUR</Text>
            <View style={styles.resultRows}>
              <View style={styles.resultRow}>
                <Text style={styles.resultKey}>Nomor</Text>
                <Text style={styles.resultVal}>+{target}</Text>
              </View>
              <View style={styles.resultRow}>
                <Text style={styles.resultKey}>Provider</Text>
                <Text style={[styles.resultVal, { color: "#e63946" }]}>{result.provider}</Text>
              </View>
              <View style={styles.resultRow}>
                <Text style={styles.resultKey}>Estimasi Umur</Text>
                <Text style={[styles.resultVal, { color: "#2ecc71", fontSize: 18 }]}>{result.age}</Text>
              </View>
            </View>
            <Text style={styles.powered}>Powered by @pakvncnt</Text>
          </View>
          <TouchableOpacity style={styles.resetBtn} onPress={() => { setPhase("input"); setTarget(""); setResult(null); }}>
            <Text style={styles.resetBtnText}>CEK NOMOR LAIN</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>KEMBALI KE MENU</Text>
          </TouchableOpacity>
        </View>
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 12 },
  label: { color: "#8892b0", fontSize: 13, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  input: { backgroundColor: "#0d1535", borderRadius: 10, borderWidth: 1, borderColor: "#2a3060", color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular", paddingHorizontal: 16, height: 52 },
  inputError: { borderColor: "#e63946" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { backgroundColor: "#e63946", borderRadius: 12, height: 54, alignItems: "center", justifyContent: "center", marginTop: 12 },
  runBtnDisabled: { opacity: 0.5 },
  runBtnText: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  resultContainer: { gap: 12 },
  resultCard: { backgroundColor: "#1a2040", borderRadius: 16, padding: 24, alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#2a3060" },
  resultTitle: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  resultRows: { width: "100%", gap: 12 },
  resultRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  resultKey: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_400Regular" },
  resultVal: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold" },
  powered: { color: "#2a3060", fontSize: 12, fontFamily: "Rajdhani_400Regular", marginTop: 8 },
  resetBtn: { backgroundColor: "#1a2040", borderRadius: 10, padding: 14, alignItems: "center", borderWidth: 1, borderColor: "#e63946" },
  resetBtnText: { color: "#e63946", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  backBtn: { backgroundColor: "#e63946", borderRadius: 10, padding: 14, alignItems: "center" },
  backBtnText: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
});
