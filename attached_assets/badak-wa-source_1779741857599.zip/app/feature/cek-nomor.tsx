import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import FeatureContainer from "@/components/FeatureContainer";
import ProgressView from "@/components/ProgressView";
import { getCardAge, getNumberStatus, getProviderInfo, validatePhone } from "@/utils/phoneData";

const STEPS = [
  "Memindai nomor target...",
  "Menghubungi database telekomunikasi...",
  "Mendapatkan informasi lengkap...",
  "Memvalidasi hasil...",
  "Data berhasil dikumpulkan!",
];

export default function CekNomorScreen() {
  const [phase, setPhase] = useState<"input" | "progress" | "result">("input");
  const [target, setTarget] = useState("");
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ provider: string; region: string; status: string; age: string } | null>(null);

  const run = () => {
    const err = validatePhone(target);
    if (err) { setError(err); return; }
    setError("");
    setPhase("progress");
  };

  const handleComplete = () => {
    const { provider, region } = getProviderInfo(target);
    const status = getNumberStatus(target);
    const age = getCardAge(target);
    setResult({ provider, region, status, age });
    setPhase("result");
  };

  return (
    <FeatureContainer
      title="CEK NOMOR"
      onBack={() => router.back()}
      scrollable={phase === "input"}
    >
      {phase === "input" && (
        <View style={styles.form}>
          <Text style={styles.label}>Nomor Target</Text>
          <TextInput
            style={[styles.input, error ? styles.inputError : null]}
            placeholder="62812xxxxxxx"
            placeholderTextColor="#4a5280"
            value={target}
            onChangeText={(t) => { setTarget(t.replace(/\D/g, "")); setError(""); }}
            keyboardType="numeric"
          />
          {error ? <Text style={styles.errorText}>{error}</Text> : null}
          <TouchableOpacity
            style={[styles.runBtn, !target && styles.runBtnDisabled]}
            onPress={run}
            disabled={!target}
            activeOpacity={0.85}
          >
            <Text style={styles.runBtnText}>CEK INFO</Text>
          </TouchableOpacity>
        </View>
      )}

      {phase === "progress" && (
        <ProgressView steps={STEPS} stepDuration={900} onComplete={handleComplete} />
      )}

      {phase === "result" && result && (
        <View style={styles.resultContainer}>
          <View style={styles.resultCard}>
            <Feather name="info" size={48} color="#2ecc71" />
            <Text style={styles.resultTitle}>INFO LENGKAP NOMOR</Text>
            <View style={styles.resultRows}>
              {[
                { key: "Nomor", val: `+${target}`, color: undefined },
                { key: "Provider", val: result.provider, color: "#e63946" as string | undefined },
                { key: "Wilayah", val: result.region, color: undefined },
                { key: "Status", val: result.status, color: result.status === "Aktif" ? "#2ecc71" as string : "#e63946" as string },
                { key: "Est. Umur Kartu", val: result.age, color: "#f4c430" as string | undefined },
              ].map(({ key, val, color }) => (
                <View key={key} style={styles.resultRow}>
                  <Text style={styles.resultKey}>{key}</Text>
                  <Text style={[styles.resultVal, color ? { color } : null]}>{val}</Text>
                </View>
              ))}
            </View>
            <Text style={styles.powered}>Powered by @pakvncnt</Text>
          </View>
          <TouchableOpacity style={styles.resetBtn} onPress={() => { setPhase("input"); setTarget(""); setResult(null); }}>
            <Text style={styles.resetBtnText}>CEK NOMOR LAIN</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Text style={styles.backBtnText}>KEMBALI KE MENU</Text>
          </TouchableOpacity>
        </View>
      )}
    </FeatureContainer>
  );
}

const styles = StyleSheet.create({
  form: { gap: 12 },
  label: { color: "#8892b0", fontSize: 13, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  input: { backgroundColor: "#0d1535", borderRadius: 10, borderWidth: 1, borderColor: "#2a3060", color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_400Regular", paddingHorizontal: 16, height: 52 },
  inputError: { borderColor: "#e63946" },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  runBtn: { backgroundColor: "#e63946", borderRadius: 12, height: 54, alignItems: "center", justifyContent: "center", marginTop: 12 },
  runBtnDisabled: { opacity: 0.5 },
  runBtnText: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  resultContainer: { gap: 12 },
  resultCard: { backgroundColor: "#1a2040", borderRadius: 16, padding: 24, alignItems: "center", gap: 12, borderWidth: 1, borderColor: "#2a3060" },
  resultTitle: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  resultRows: { width: "100%", gap: 10 },
  resultRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  resultKey: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_400Regular" },
  resultVal: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold", textAlign: "right", flex: 1, marginLeft: 8 },
  powered: { color: "#2a3060", fontSize: 12, fontFamily: "Rajdhani_400Regular", marginTop: 8 },
  resetBtn: { backgroundColor: "#1a2040", borderRadius: 10, padding: 14, alignItems: "center", borderWidth: 1, borderColor: "#e63946" },
  resetBtnText: { color: "#e63946", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  backBtn: { backgroundColor: "#e63946", borderRadius: 10, padding: 14, alignItems: "center" },
  backBtnText: { color: "#ffffff", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
});
