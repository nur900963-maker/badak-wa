import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "@/components/BrandingBar";
import { useAuth } from "@/context/AuthContext";

type FeatureItem = {
  id: string;
  label: string;
  icon: keyof typeof Feather.glyphMap;
  route: string;
  color: string;
  isVip?: boolean;
};

const FEATURES: FeatureItem[] = [
  { id: "badak-wa", label: "Badak WA", icon: "zap", route: "/feature/badak-wa", color: "#e63946" },
  { id: "unband", label: "Unband", icon: "shield", route: "/feature/unband", color: "#2ecc71" },
  { id: "bug-menu", label: "Bug Menu", icon: "alert-triangle", route: "/feature/bug-menu", color: "#ff8c00" },
  { id: "cek-provider", label: "Cek Provider", icon: "wifi", route: "/feature/check-provider", color: "#1a6ef7" },
  { id: "report", label: "Report", icon: "flag", route: "/feature/report", color: "#b10dc9" },
  { id: "kill", label: "Kill VPS/Panel", icon: "power", route: "/feature/kill", color: "#ff4136" },
  { id: "cek-umur", label: "Cek Umur", icon: "clock", route: "/feature/cek-umur", color: "#00d4ff" },
  { id: "cek-nomor", label: "Cek Nomor", icon: "search", route: "/feature/cek-nomor", color: "#3ddc84" },
  { id: "vip", label: "Fitur VIP", icon: "star", route: "/vip", color: "#f4c430", isVip: true },
];

function getRemainingTime(expiredAt: number | null): string {
  if (expiredAt === null) return "PERMANEN";
  const diff = expiredAt - Date.now();
  if (diff <= 0) return "HABIS";
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days > 0) return `${days}h ${hours}j`;
  return `${hours} jam`;
}

export default function DashboardScreen() {
  const { session, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom + 84;

  const [logoutModal, setLogoutModal] = useState(false);
  const [vipModal, setVipModal] = useState(false);

  const handleFeatureTap = (item: FeatureItem) => {
    if (item.isVip) { setVipModal(true); return; }
    router.push(item.route as `/${string}`);
  };

  const handleLogout = async () => {
    setLogoutModal(false);
    await logout();
    router.replace("/login");
  };

  if (!session) return null;
  const remaining = getRemainingTime(session.expiredAt);
  const isPerm = session.expiredAt === null;

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <BrandingBar />

      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerEmoji}>🦏</Text>
          <Text style={styles.headerTitle}>BADAK WA</Text>
        </View>
        <TouchableOpacity onPress={() => setLogoutModal(true)} style={styles.logoutBtn}>
          <Feather name="log-out" size={18} color="#e63946" />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingBottom: bottomPad }]}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={["#1a2040", "#0f1628"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.welcomeCard}
        >
          <View style={styles.welcomeTop}>
            <View style={styles.avatarSmall}>
              <Text style={styles.avatarChar}>{session.username.charAt(0).toUpperCase()}</Text>
            </View>
            <View style={styles.welcomeInfo}>
              <Text style={styles.welcomeGreet}>Halo, {session.username}!</Text>
              <Text style={styles.welcomeSub}>Selamat datang di Badak WA</Text>
            </View>
            <View style={[styles.badge, isPerm ? styles.badgePerm : styles.badgeActive]}>
              <Text style={[styles.badgeText, isPerm ? styles.badgeTextPerm : null]}>
                {isPerm ? "♾️ PERM" : "✅ AKTIF"}
              </Text>
            </View>
          </View>
          <View style={styles.timerRow}>
            <Feather name="clock" size={13} color="#4da6ff" />
            <Text style={styles.timerText}>Sisa Akses: </Text>
            <Text style={styles.timerValue}>{remaining}</Text>
          </View>
        </LinearGradient>

        <Text style={styles.sectionLabel}>▸ MENU FITUR</Text>

        <View style={styles.grid}>
          {FEATURES.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.featureCard}
              onPress={() => handleFeatureTap(item)}
              activeOpacity={0.75}
            >
              <LinearGradient
                colors={[`${item.color}22`, "#0a0f2c"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.featureCardGradient}
              >
                {item.isVip && (
                  <View style={styles.vipBadge}>
                    <Text style={styles.vipBadgeText}>VIP</Text>
                  </View>
                )}
                <View style={[styles.featureIconWrap, { backgroundColor: `${item.color}22`, borderColor: `${item.color}55` }]}>
                  <Feather name={item.icon} size={24} color={item.color} />
                </View>
                <Text style={[styles.featureLabel, { color: item.isVip ? item.color : "#ffffff" }]}>
                  {item.label}
                </Text>
                <View style={[styles.featureAccent, { backgroundColor: item.color }]} />
              </LinearGradient>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <Modal visible={logoutModal} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Logout?</Text>
            <Text style={styles.modalText}>Yakin ingin keluar dari akun ini?</Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.modalBtnCancel} onPress={() => setLogoutModal(false)}>
                <Text style={styles.modalBtnCancelText}>BATAL</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalBtnConfirm} onPress={() => void handleLogout()}>
                <Text style={styles.modalBtnConfirmText}>LOGOUT</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={vipModal} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <View style={styles.vipModalIcon}><Text style={{ fontSize: 36 }}>🔒</Text></View>
            <Text style={[styles.modalTitle, { color: "#f4c430" }]}>Fitur VIP</Text>
            <Text style={styles.modalText}>Fitur ini khusus pengguna VIP.{"\n"}Hubungi @pakvncnt untuk upgrade.</Text>
            <TouchableOpacity style={[styles.modalBtnConfirm, { backgroundColor: "#f4c430" }]} onPress={() => setVipModal(false)}>
              <Text style={[styles.modalBtnConfirmText, { color: "#000" }]}>TUTUP</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0a0f2c" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#1a2040",
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  headerEmoji: { fontSize: 22 },
  headerTitle: { color: "#ffffff", fontSize: 22, fontFamily: "Rajdhani_700Bold", letterSpacing: 3 },
  logoutBtn: { padding: 8, backgroundColor: "#1a1a2e", borderRadius: 8, borderWidth: 1, borderColor: "#e6394630" },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 16 },
  welcomeCard: {
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: "#2a3060",
    gap: 12,
  },
  welcomeTop: { flexDirection: "row", alignItems: "center", gap: 12 },
  avatarSmall: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#e63946",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarChar: { color: "#fff", fontSize: 20, fontFamily: "Rajdhani_700Bold" },
  welcomeInfo: { flex: 1 },
  welcomeGreet: { color: "#ffffff", fontSize: 18, fontFamily: "Rajdhani_700Bold" },
  welcomeSub: { color: "#8892b0", fontSize: 12, fontFamily: "Rajdhani_400Regular", marginTop: 1 },
  badge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8 },
  badgeActive: { backgroundColor: "#0d2a1a", borderWidth: 1, borderColor: "#2ecc7155" },
  badgePerm: { backgroundColor: "#1a1500", borderWidth: 1, borderColor: "#f4c43055" },
  badgeText: { color: "#2ecc71", fontSize: 11, fontFamily: "Rajdhani_700Bold", letterSpacing: 0.5 },
  badgeTextPerm: { color: "#f4c430" },
  timerRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  timerText: { color: "#8892b0", fontSize: 13, fontFamily: "Rajdhani_400Regular" },
  timerValue: { color: "#4da6ff", fontFamily: "Rajdhani_700Bold", fontSize: 14 },
  sectionLabel: { color: "#4da6ff", fontSize: 13, fontFamily: "Rajdhani_700Bold", letterSpacing: 2 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  featureCard: {
    width: "47.5%",
    borderRadius: 16,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  featureCardGradient: {
    padding: 16,
    alignItems: "center",
    gap: 10,
    position: "relative",
  },
  featureIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
  featureLabel: {
    fontSize: 13,
    fontFamily: "Rajdhani_700Bold",
    textAlign: "center",
    letterSpacing: 0.5,
  },
  featureAccent: { position: "absolute", bottom: 0, left: 0, right: 0, height: 2 },
  vipBadge: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "#f4c430",
    borderRadius: 4,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  vipBadgeText: { color: "#000", fontSize: 9, fontFamily: "Rajdhani_700Bold" },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.75)", alignItems: "center", justifyContent: "center", padding: 24 },
  modal: {
    backgroundColor: "#111827",
    borderRadius: 20,
    padding: 24,
    width: "100%",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#2a3060",
    gap: 12,
  },
  vipModalIcon: { width: 70, height: 70, borderRadius: 35, backgroundColor: "#1a1500", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "#f4c430" },
  modalTitle: { color: "#ffffff", fontSize: 22, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  modalText: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_400Regular", textAlign: "center", lineHeight: 22 },
  modalBtns: { flexDirection: "row", gap: 12, width: "100%" },
  modalBtnCancel: { flex: 1, backgroundColor: "#0d1535", borderRadius: 10, padding: 12, alignItems: "center", borderWidth: 1, borderColor: "#2a3060" },
  modalBtnCancelText: { color: "#8892b0", fontFamily: "Rajdhani_700Bold", fontSize: 14 },
  modalBtnConfirm: { flex: 1, backgroundColor: "#e63946", borderRadius: 10, padding: 12, alignItems: "center" },
  modalBtnConfirmText: { color: "#ffffff", fontFamily: "Rajdhani_700Bold", fontSize: 14 },
});
