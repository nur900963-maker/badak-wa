import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "@/components/BrandingBar";
import { useAuth } from "@/context/AuthContext";

export default function ProfileScreen() {
  const { session, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom + 84;
  const [logoutModal, setLogoutModal] = useState(false);

  if (!session) return null;

  const isPerm = session.expiredAt === null;
  const expiredStr = isPerm
    ? "Permanen"
    : session.expiredAt
      ? new Date(session.expiredAt).toLocaleDateString("id-ID", {
          day: "numeric",
          month: "long",
          year: "numeric",
        })
      : "-";

  const remaining = isPerm
    ? "Tidak terbatas"
    : session.expiredAt
      ? (() => {
          const diff = session.expiredAt - Date.now();
          if (diff <= 0) return "Habis";
          const days = Math.floor(diff / (1000 * 60 * 60 * 24));
          return `${days} hari lagi`;
        })()
      : "-";

  const handleLogout = async () => {
    setLogoutModal(false);
    await logout();
    router.replace("/login");
  };

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <BrandingBar />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>PROFIL</Text>
      </View>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: bottomPad }]}
      >
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {session.username.charAt(0).toUpperCase()}
            </Text>
          </View>
          <Text style={styles.username}>{session.username}</Text>
          <View
            style={[
              styles.statusBadge,
              isPerm ? styles.badgePerm : styles.badgeActive,
            ]}
          >
            <Text style={styles.statusText}>
              {isPerm ? "PERMANEN" : "AKTIF"}
            </Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.infoRow}>
            <Feather name="user" size={16} color="#8892b0" />
            <Text style={styles.infoLabel}>Username</Text>
            <Text style={styles.infoValue}>{session.username}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Feather name="shield" size={16} color="#8892b0" />
            <Text style={styles.infoLabel}>Status</Text>
            <Text style={[styles.infoValue, { color: "#2ecc71" }]}>
              {isPerm ? "Permanen" : "Aktif"}
            </Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Feather name="calendar" size={16} color="#8892b0" />
            <Text style={styles.infoLabel}>Expired</Text>
            <Text style={styles.infoValue}>{expiredStr}</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Feather name="clock" size={16} color="#8892b0" />
            <Text style={styles.infoLabel}>Sisa Waktu</Text>
            <Text style={[styles.infoValue, { color: "#e63946" }]}>
              {remaining}
            </Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Feather name="star" size={16} color="#8892b0" />
            <Text style={styles.infoLabel}>Tipe Akun</Text>
            <Text
              style={[
                styles.infoValue,
                { color: session.isVip ? "#f4c430" : "#8892b0" },
              ]}
            >
              {session.isVip ? "VIP" : "Regular"}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={() => setLogoutModal(true)}
          activeOpacity={0.85}
        >
          <Feather name="log-out" size={18} color="#ffffff" />
          <Text style={styles.logoutText}>LOGOUT</Text>
        </TouchableOpacity>

        <Text style={styles.contact}>
          Hubungi @pakvncnt untuk perpanjang akses
        </Text>
      </ScrollView>

      <Modal visible={logoutModal} transparent animationType="fade">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Konfirmasi Logout</Text>
            <Text style={styles.modalText}>
              Yakin ingin keluar dari akun ini?
            </Text>
            <View style={styles.modalBtns}>
              <TouchableOpacity
                style={styles.modalBtnCancel}
                onPress={() => setLogoutModal(false)}
              >
                <Text style={styles.modalBtnCancelText}>BATAL</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalBtnConfirm}
                onPress={() => void handleLogout()}
              >
                <Text style={styles.modalBtnConfirmText}>LOGOUT</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0a0f2c" },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#2a3060",
  },
  headerTitle: {
    color: "#ffffff",
    fontSize: 22,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 3,
  },
  content: { padding: 24, gap: 20 },
  avatarContainer: { alignItems: "center", gap: 10 },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#e63946",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#ffffff",
    fontSize: 36,
    fontFamily: "Rajdhani_700Bold",
  },
  username: {
    color: "#ffffff",
    fontSize: 24,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 1,
  },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 6 },
  badgeActive: { backgroundColor: "#1a3a2a" },
  badgePerm: { backgroundColor: "#3a2a00" },
  statusText: {
    color: "#2ecc71",
    fontSize: 13,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 1,
  },
  card: {
    backgroundColor: "#1a2040",
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  infoLabel: {
    color: "#8892b0",
    fontSize: 14,
    fontFamily: "Rajdhani_400Regular",
    flex: 1,
  },
  infoValue: {
    color: "#ffffff",
    fontSize: 14,
    fontFamily: "Rajdhani_700Bold",
    textAlign: "right",
  },
  divider: { height: 1, backgroundColor: "#2a3060", marginVertical: 12 },
  logoutBtn: {
    backgroundColor: "#e63946",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  logoutText: {
    color: "#ffffff",
    fontSize: 16,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 2,
  },
  contact: {
    color: "#2a3060",
    fontSize: 12,
    fontFamily: "Rajdhani_400Regular",
    textAlign: "center",
  },
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modal: {
    backgroundColor: "#1a2040",
    borderRadius: 16,
    padding: 24,
    width: "100%",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#2a3060",
    gap: 12,
  },
  modalTitle: {
    color: "#ffffff",
    fontSize: 20,
    fontFamily: "Rajdhani_700Bold",
  },
  modalText: {
    color: "#8892b0",
    fontSize: 14,
    fontFamily: "Rajdhani_400Regular",
    textAlign: "center",
  },
  modalBtns: { flexDirection: "row", gap: 12, width: "100%" },
  modalBtnCancel: {
    flex: 1,
    backgroundColor: "#0d1535",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  modalBtnCancelText: {
    color: "#8892b0",
    fontFamily: "Rajdhani_700Bold",
    fontSize: 14,
  },
  modalBtnConfirm: {
    flex: 1,
    backgroundColor: "#e63946",
    borderRadius: 10,
    padding: 12,
    alignItems: "center",
  },
  modalBtnConfirmText: {
    color: "#ffffff",
    fontFamily: "Rajdhani_700Bold",
    fontSize: 14,
  },
});
