import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "@/components/BrandingBar";
import { useAuth } from "@/context/AuthContext";

const ERROR_MESSAGES: Record<string, string> = {
  USER_NOT_FOUND: "⚠ Akun tidak ditemukan. Hubungi @pakvncnt",
  WRONG_PASSWORD: "⚠ Password salah. Coba lagi atau hubungi @pakvncnt",
  EXPIRED: "⚠ Akses habis. Hubungi @pakvncnt untuk perpanjang",
};

export default function LoginScreen() {
  const { login } = useAuth();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const shakeAnim = useRef(new Animated.Value(0)).current;

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8, duration: 60, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 60, useNativeDriver: true }),
    ]).start();
  };

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      setError("⚠ Username dan password tidak boleh kosong");
      shake();
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await login(username.trim(), password);
      if (result === "OK") {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      } else {
        void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        setError(ERROR_MESSAGES[result] ?? "Terjadi kesalahan");
        shake();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: topPad }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <BrandingBar />
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.logoContainer}>
          <LinearGradient
            colors={["#e63946", "#8b0000"]}
            style={styles.logoCircle}
          >
            <Text style={styles.logoEmoji}>🦏</Text>
          </LinearGradient>
          <Text style={styles.appName}>BADAK WA</Text>
          <View style={styles.taglinePill}>
            <Text style={styles.tagline}>Premium WhatsApp Tools</Text>
          </View>
        </View>

        <Animated.View style={[styles.form, { transform: [{ translateX: shakeAnim }] }]}>
          <View style={styles.inputWrapper}>
            <View style={styles.inputIcon}>
              <Feather name="user" size={16} color="#4da6ff" />
            </View>
            <TextInput
              style={styles.input}
              placeholder="Username"
              placeholderTextColor="#4a5280"
              value={username}
              onChangeText={(t) => { setUsername(t); setError(""); }}
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
            />
          </View>

          <View style={styles.inputWrapper}>
            <View style={styles.inputIcon}>
              <Feather name="lock" size={16} color="#4da6ff" />
            </View>
            <TextInput
              style={[styles.input, { flex: 1 }]}
              placeholder="Password"
              placeholderTextColor="#4a5280"
              value={password}
              onChangeText={(t) => { setPassword(t); setError(""); }}
              secureTextEntry={!showPassword}
              autoCapitalize="none"
              autoCorrect={false}
              editable={!loading}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
              <Feather name={showPassword ? "eye-off" : "eye"} size={16} color="#8892b0" />
            </TouchableOpacity>
          </View>

          {error ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            onPress={() => void handleLogin()}
            disabled={loading}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={loading ? ["#2a3060", "#2a3060"] : ["#e63946", "#c0392b"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.loginBtn}
            >
              {loading
                ? <ActivityIndicator color="#ffffff" />
                : <Text style={styles.loginBtnText}>⚡ LOGIN</Text>}
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>

        <Text style={styles.hint}>Demo: demo / demo123</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#060b1e" },
  scroll: { flexGrow: 1, justifyContent: "center", padding: 24 },
  logoContainer: { alignItems: "center", marginBottom: 44, gap: 12 },
  logoCircle: {
    width: 96,
    height: 96,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    elevation: 8,
    shadowColor: "#e63946",
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  logoEmoji: { fontSize: 50 },
  appName: {
    color: "#ffffff",
    fontSize: 40,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 6,
  },
  taglinePill: {
    backgroundColor: "#1a2040",
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  tagline: { color: "#4da6ff", fontSize: 13, fontFamily: "Rajdhani_400Regular", letterSpacing: 1 },
  form: { gap: 14 },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111827",
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#2a3060",
    height: 56,
    paddingHorizontal: 14,
    gap: 10,
  },
  inputIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#1a2040",
    alignItems: "center",
    justifyContent: "center",
  },
  input: {
    flex: 1,
    color: "#ffffff",
    fontSize: 16,
    fontFamily: "Rajdhani_400Regular",
  },
  eyeBtn: { padding: 4 },
  errorBox: {
    backgroundColor: "#1a0a0a",
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: "#e6394655",
  },
  errorText: { color: "#e63946", fontSize: 13, fontFamily: "Rajdhani_400Regular", textAlign: "center" },
  loginBtn: {
    borderRadius: 14,
    height: 56,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  loginBtnText: { color: "#ffffff", fontSize: 20, fontFamily: "Rajdhani_700Bold", letterSpacing: 4 },
  hint: { color: "#2a3060", fontSize: 12, fontFamily: "Rajdhani_400Regular", textAlign: "center", marginTop: 32 },
});
