import { Redirect } from "expo-router";
import { useAuth } from "@/context/AuthContext";
import { View, ActivityIndicator } from "react-native";

export default function Index() {
  const { session, loading } = useAuth();
  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: "#0a0f2c", alignItems: "center", justifyContent: "center" }}>
        <ActivityIndicator color="#e63946" size="large" />
      </View>
    );
  }
  if (session) return <Redirect href="/(tabs)" />;
  return <Redirect href="/login" />;
}
