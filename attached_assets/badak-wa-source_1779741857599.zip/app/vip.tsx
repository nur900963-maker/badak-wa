import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "@/components/BrandingBar";

const VIP_FEATURES = [
  { label: "Badak WA Pro", desc: "Blast hingga 1000 target sekaligus", icon: "zap" as const },
  { label: "Advanced Bug", desc: "Bug eksklusif dengan success rate tinggi", icon: "alert-triangle" as const },
  { label: "Kill Panel VIP", desc: "Kill panel tanpa delay dengan stealth mode", icon: "power" as const },
  { label: "Kill VPS VIP", desc: "Kill VPS dengan bypass firewall otomatis", icon: "server" as const },
  { label: "Unband Pro", desc: "Unband massal dengan metode force lanjutan", icon: "shield" as const },
  { label: "Report Pro", desc: "Report hingga 10.000 dalam sekali jalan", icon: "flag" as const },
  { label: "Multi Target", desc: "Jalankan semua fitur ke banyak target", icon: "users" as const },
  { label: "Fast Mode", desc: "Eksekusi 10x lebih cepat dari versi reguler", icon: "fast-forward" as const },
];

export default function VipScreen() {
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <BrandingBar />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color="#ffffff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>FITUR VIP</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 24 }]}
      >
        <View style={styles.banner}>
          <Feather name="star" size={36} color="#f4c430" />
          <Text style={styles.bannerTitle}>Akses VIP Premium</Text>
          <Text style={styles.bannerSub}>
            Dapatkan akses ke semua fitur eksklusif.{"\n"}Hubungi @pakvncnt untuk info lebih lanjut.
          </Text>
          <TouchableOpacity style={styles.contactBtn} activeOpacity={0.85}>
            <Text style={styles.contactBtnText}>HUBUNGI @pakvncnt</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionLabel}>FITUR EKSKLUSIF VIP</Text>
        {VIP_FEATURES.map((f) => (
          <View key={f.label} style={styles.featureRow}>
            <View style={styles.featureIcon}>
              <Feather name={f.icon} size={22} color="#f4c430" />
            </View>
            <View style={styles.featureInfo}>
              <Text style={styles.featureName}>{f.label}</Text>
              <Text style={styles.featureDesc}>{f.desc}</Text>
            </View>
            <View style={styles.lockIcon}>
              <Feather name="lock" size={16} color="#f4c430" />
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0a0f2c" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#2a3060",
  },
  backBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  headerTitle: {
    color: "#f4c430",
    fontSize: 20,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 2,
  },
  content: { padding: 20, gap: 16 },
  banner: {
    backgroundColor: "#1a1800",
    borderRadius: 16,
    padding: 24,
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: "#f4c430",
  },
  bannerTitle: {
    color: "#f4c430",
    fontSize: 22,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 1,
  },
  bannerSub: {
    color: "#8892b0",
    fontSize: 13,
    fontFamily: "Rajdhani_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
  contactBtn: {
    marginTop: 8,
    backgroundColor: "#f4c430",
    borderRadius: 10,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  contactBtnText: {
    color: "#000000",
    fontSize: 14,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 1,
  },
  sectionLabel: {
    color: "#8892b0",
    fontSize: 12,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 2,
  },
  featureRow: {
    backgroundColor: "#1a2040",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  featureIcon: {
    width: 44,
    height: 44,
    borderRadius: 10,
    backgroundColor: "#1a1800",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#f4c430",
  },
  featureInfo: { flex: 1 },
  featureName: {
    color: "#ffffff",
    fontSize: 16,
    fontFamily: "Rajdhani_700Bold",
  },
  featureDesc: {
    color: "#8892b0",
    fontSize: 12,
    fontFamily: "Rajdhani_400Regular",
    marginTop: 2,
  },
  lockIcon: {
    width: 30,
    height: 30,
    alignItems: "center",
    justifyContent: "center",
  },
});
