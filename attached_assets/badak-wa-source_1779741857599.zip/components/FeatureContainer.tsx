import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BrandingBar from "./BrandingBar";

interface Props {
  title: string;
  onBack: () => void;
  children: React.ReactNode;
  scrollable?: boolean;
}

export default function FeatureContainer({
  title,
  onBack,
  children,
  scrollable = true,
}: Props) {
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const content = scrollable ? (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.scrollContent}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  ) : (
    <View style={styles.flex}>{children}</View>
  );

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <BrandingBar />
      <LinearGradient
        colors={["#111827", "#0a0f2c"]}
        style={styles.header}
      >
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Feather name="chevron-left" size={24} color="#ffffff" />
        </TouchableOpacity>
        <Text style={styles.title}>{title}</Text>
        <View style={{ width: 40 }} />
      </LinearGradient>
      <View style={styles.headerUnderline} />
      {content}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0a0f2c",
  },
  flex: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 12,
    paddingVertical: 14,
  },
  headerUnderline: {
    height: 1,
    backgroundColor: "#1a6ef7",
    opacity: 0.4,
  },
  backBtn: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#1a2040",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  title: {
    color: "#ffffff",
    fontSize: 20,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 2,
  },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 48 },
});
