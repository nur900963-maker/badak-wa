import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, TouchableOpacity, View } from "react-native";

interface Props {
  title: string;
  iconName?: keyof typeof Feather.glyphMap;
  iconColor?: string;
  details?: string;
  onReset: () => void;
  onBack: () => void;
}

export default function ResultView({
  title,
  iconName = "check-circle",
  iconColor = "#2ecc71",
  details,
  onReset,
  onBack,
}: Props) {
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    void Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    Animated.parallel([
      Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, tension: 60, friction: 8 }),
      Animated.timing(opacityAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <Animated.View style={[styles.container, { opacity: opacityAnim }]}>
      <Animated.View style={[styles.cardWrap, { transform: [{ scale: scaleAnim }] }]}>
        <LinearGradient
          colors={[`${iconColor}15`, "#0a0f2c"]}
          style={styles.card}
        >
          <View style={[styles.iconCircle, { borderColor: `${iconColor}55`, backgroundColor: `${iconColor}15` }]}>
            <Feather name={iconName} size={52} color={iconColor} />
          </View>
          <Text style={[styles.title, { color: iconColor }]}>{title}</Text>
          {details ? (
            <View style={styles.detailsBox}>
              {details.split("\n").map((line, i) => (
                <Text key={i} style={styles.detailLine}>{line}</Text>
              ))}
            </View>
          ) : null}
          <Text style={styles.powered}>⚡ Powered by @pakvncnt</Text>
        </LinearGradient>
      </Animated.View>

      <TouchableOpacity style={styles.resetBtn} onPress={onReset} activeOpacity={0.8}>
        <Text style={styles.resetBtnText}>↩ JALANKAN LAGI</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onBack} activeOpacity={0.85}>
        <LinearGradient
          colors={["#e63946", "#c0392b"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={styles.backBtn}
        >
          <Text style={styles.backBtnText}>← KEMBALI KE MENU</Text>
        </LinearGradient>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center", gap: 12 },
  cardWrap: { borderRadius: 20, overflow: "hidden", borderWidth: 1, borderColor: "#2a3060" },
  card: { padding: 28, alignItems: "center", gap: 14 },
  iconCircle: {
    width: 90,
    height: 90,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 2,
  },
  title: {
    fontSize: 24,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 2,
    textAlign: "center",
  },
  detailsBox: {
    backgroundColor: "#111827",
    borderRadius: 12,
    padding: 14,
    width: "100%",
    gap: 4,
    borderWidth: 1,
    borderColor: "#2a3060",
  },
  detailLine: { color: "#8892b0", fontSize: 14, fontFamily: "Rajdhani_400Regular", lineHeight: 22 },
  powered: { color: "#2a3060", fontSize: 12, fontFamily: "Rajdhani_400Regular", letterSpacing: 1 },
  resetBtn: {
    borderRadius: 14,
    padding: 15,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#2a3060",
    backgroundColor: "#111827",
  },
  resetBtnText: { color: "#8892b0", fontSize: 15, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
  backBtn: { borderRadius: 14, height: 54, alignItems: "center", justifyContent: "center" },
  backBtnText: { color: "#ffffff", fontSize: 16, fontFamily: "Rajdhani_700Bold", letterSpacing: 1 },
});
