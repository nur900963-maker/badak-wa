import { LinearGradient } from "expo-linear-gradient";
import React, { useEffect, useRef, useState } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";

interface Props {
  steps: string[];
  stepDuration?: number;
  onComplete: () => void;
}

export default function ProgressView({
  steps,
  stepDuration = 1200,
  onComplete,
}: Props) {
  const [currentStep, setCurrentStep] = useState(0);
  const [doneSteps, setDoneSteps] = useState<number[]>([]);
  const progress = useRef(new Animated.Value(0)).current;
  const completedRef = useRef(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.03, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    let stepIdx = 0;
    completedRef.current = false;

    function runStep() {
      if (completedRef.current) return;
      if (stepIdx >= steps.length) {
        onComplete();
        return;
      }
      setCurrentStep(stepIdx);
      Animated.timing(progress, {
        toValue: (stepIdx + 1) / steps.length,
        duration: stepDuration,
        useNativeDriver: false,
      }).start(() => {
        setDoneSteps((prev) => [...prev, stepIdx]);
        stepIdx++;
        setTimeout(runStep, 100);
      });
    }
    runStep();
    return () => { completedRef.current = true; };
  }, []);

  const widthInterp = progress.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  const percentInterp = progress.interpolate({ inputRange: [0, 1], outputRange: [0, 100] });

  return (
    <View style={styles.container}>
      <Animated.Text style={[styles.title, { transform: [{ scale: pulseAnim }] }]}>
        ⚡ MEMPROSES...
      </Animated.Text>

      <View style={styles.barOuter}>
        <Animated.View style={[styles.barWrap, { width: widthInterp }]}>
          <LinearGradient
            colors={["#1a6ef7", "#8b5cf6", "#e63946"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.bar}
          />
        </Animated.View>
      </View>

      <Animated.Text style={styles.percent}>
        {percentInterp.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] })}
      </Animated.Text>

      <View style={styles.stepsContainer}>
        {steps.map((step, i) => {
          const isDone = doneSteps.includes(i);
          const isActive = i === currentStep;
          return (
            <View key={i} style={[styles.stepRow, isActive && styles.stepRowActive]}>
              <View style={[
                styles.stepDotWrap,
                isDone ? styles.dotWrapDone : isActive ? styles.dotWrapActive : styles.dotWrapPending,
              ]}>
                <Text style={styles.stepDotText}>
                  {isDone ? "✓" : isActive ? "▶" : `${i + 1}`}
                </Text>
              </View>
              <Text style={[
                styles.stepText,
                isDone ? styles.stepDone : isActive ? styles.stepActive : styles.stepPending,
              ]}>
                {step}
              </Text>
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, justifyContent: "center" },
  title: {
    color: "#4da6ff",
    fontSize: 22,
    fontFamily: "Rajdhani_700Bold",
    textAlign: "center",
    marginBottom: 32,
    letterSpacing: 3,
  },
  barOuter: {
    height: 12,
    backgroundColor: "#111827",
    borderRadius: 6,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#2a3060",
    marginBottom: 8,
  },
  barWrap: { height: "100%", borderRadius: 6, overflow: "hidden" },
  bar: { flex: 1 },
  percent: {
    color: "#4da6ff",
    fontSize: 13,
    fontFamily: "Rajdhani_700Bold",
    textAlign: "right",
    marginBottom: 28,
    letterSpacing: 1,
  },
  stepsContainer: { gap: 10 },
  stepRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 10,
    borderRadius: 10,
  },
  stepRowActive: { backgroundColor: "#0d1535", borderWidth: 1, borderColor: "#1a6ef7" },
  stepDotWrap: {
    width: 26,
    height: 26,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  dotWrapDone: { backgroundColor: "#0d2a1a" },
  dotWrapActive: { backgroundColor: "#1a2a4a" },
  dotWrapPending: { backgroundColor: "#111827" },
  stepDotText: { fontSize: 12, color: "#ffffff", fontFamily: "Rajdhani_700Bold" },
  stepText: { fontSize: 14, fontFamily: "Rajdhani_400Regular", flex: 1 },
  stepDone: { color: "#2ecc71" },
  stepActive: { color: "#ffffff" },
  stepPending: { color: "#2a3060" },
});
