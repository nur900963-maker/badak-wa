import React, { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";

const TEXT = "⚡ DEV @pakvncnt  •  Creator @pakvncnt  •  Channel @testipakvncnt  •  ";

export default function BrandingBar() {
  const scrollX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const animate = () => {
      scrollX.setValue(0);
      Animated.timing(scrollX, {
        toValue: -600,
        duration: 12000,
        useNativeDriver: true,
      }).start(() => animate());
    };
    animate();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.leftGlow} />
      <View style={styles.overflow}>
        <Animated.Text
          style={[styles.text, { transform: [{ translateX: scrollX }] }]}
          numberOfLines={1}
        >
          {TEXT.repeat(4)}
        </Animated.Text>
      </View>
      <View style={styles.rightGlow} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#060b1e",
    paddingVertical: 7,
    borderBottomWidth: 1,
    borderBottomColor: "#1a6ef7",
    flexDirection: "row",
    alignItems: "center",
    overflow: "hidden",
  },
  overflow: { flex: 1, overflow: "hidden" },
  text: {
    color: "#4da6ff",
    fontSize: 12,
    fontFamily: "Rajdhani_700Bold",
    letterSpacing: 1,
    width: 2000,
  },
  leftGlow: {
    position: "absolute",
    left: 0,
    top: 0,
    bottom: 0,
    width: 20,
    backgroundColor: "#060b1e",
    zIndex: 1,
  },
  rightGlow: {
    position: "absolute",
    right: 0,
    top: 0,
    bottom: 0,
    width: 20,
    backgroundColor: "#060b1e",
    zIndex: 1,
  },
});
